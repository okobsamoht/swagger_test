//! Server implementation of swagger_client.

#![allow(unused_imports)]

use futures::{self, Future};
use chrono;

use std::collections::HashMap;

use std::marker::PhantomData;

use swagger;
use swagger::{Has, XSpanIdString};

use swagger_client::{Api, ApiError,
                      AddArticleResponse,
                      DeleteArticleResponse,
                      GetArticleByIdResponse,
                      UpdateArticleResponse,
                      UpdateArticleWithFormResponse
};
use swagger_client::models;

#[derive(Copy, Clone)]
pub struct Server<C> {
    marker: PhantomData<C>,
}

impl<C> Server<C> {
    pub fn new() -> Self {
        Server{marker: PhantomData}
    }
}

impl<C> Api<C> for Server<C> where C: Has<XSpanIdString>{

    /// Add a new article to the db
    fn add_article(&self, body: models::Article, context: &C) -> Box<Future<Item=AddArticleResponse, Error=ApiError>> {
        let context = context.clone();
        println!("add_article({:?}) - X-Span-ID: {:?}", body, context.get().0.clone());
        Box::new(futures::failed("Generic failure".into()))
    }

    /// Deletes a article
    fn delete_article(&self, article_id: i64, context: &C) -> Box<Future<Item=DeleteArticleResponse, Error=ApiError>> {
        let context = context.clone();
        println!("delete_article({}) - X-Span-ID: {:?}", article_id, context.get().0.clone());
        Box::new(futures::failed("Generic failure".into()))
    }

    /// Find article by ID
    fn get_article_by_id(&self, article_id: i64, context: &C) -> Box<Future<Item=GetArticleByIdResponse, Error=ApiError>> {
        let context = context.clone();
        println!("get_article_by_id({}) - X-Span-ID: {:?}", article_id, context.get().0.clone());
        Box::new(futures::failed("Generic failure".into()))
    }

    /// Update an existing article
    fn update_article(&self, body: models::Article, context: &C) -> Box<Future<Item=UpdateArticleResponse, Error=ApiError>> {
        let context = context.clone();
        println!("update_article({:?}) - X-Span-ID: {:?}", body, context.get().0.clone());
        Box::new(futures::failed("Generic failure".into()))
    }

    /// Updates a article in the db with form data
    fn update_article_with_form(&self, article_id: i64, status: Option<String>, context: &C) -> Box<Future<Item=UpdateArticleWithFormResponse, Error=ApiError>> {
        let context = context.clone();
        println!("update_article_with_form({}, {:?}) - X-Span-ID: {:?}", article_id, status, context.get().0.clone());
        Box::new(futures::failed("Generic failure".into()))
    }

}
