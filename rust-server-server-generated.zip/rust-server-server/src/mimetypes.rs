/// mime types for requests and responses

pub mod responses {
    use hyper::mime::*;

    // The macro is called per-operation to beat the recursion limit
    /// Create Mime objects for the response content types for GetArticleById
    lazy_static! {
        pub static ref GET_ARTICLE_BY_ID_SUCCESSFUL_OPERATION: Mime = "application/json".parse().unwrap();
    }

}

pub mod requests {
    use hyper::mime::*;
   /// Create Mime objects for the request content types for AddArticle
    lazy_static! {
        pub static ref ADD_ARTICLE: Mime = "application/json".parse().unwrap();
    }
   /// Create Mime objects for the request content types for UpdateArticle
    lazy_static! {
        pub static ref UPDATE_ARTICLE: Mime = "application/json".parse().unwrap();
    }
   /// Create Mime objects for the request content types for UpdateArticleWithForm
    lazy_static! {
        pub static ref UPDATE_ARTICLE_WITH_FORM: Mime = "application/x-www-form-urlencoded".parse().unwrap();
    }

}
