# \ArticleApi

All URIs are relative to *https://articledb.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddArticle**](ArticleApi.md#AddArticle) | **Post** /article | Add a new article to the db
[**DeleteArticle**](ArticleApi.md#DeleteArticle) | **Delete** /article/{articleId} | Deletes a article
[**GetArticleById**](ArticleApi.md#GetArticleById) | **Get** /article/{articleId} | Find article by ID
[**UpdateArticle**](ArticleApi.md#UpdateArticle) | **Put** /article | Update an existing article
[**UpdateArticleWithForm**](ArticleApi.md#UpdateArticleWithForm) | **Post** /article/{articleId} | Updates a article in the db with form data


# **AddArticle**
> AddArticle(ctx, body)
Add a new article to the db



### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Article**](Article.md)| Article object that needs to be added to the db | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **DeleteArticle**
> DeleteArticle(ctx, articleId)
Deletes a article



### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **articleId** | **int64**| Article id to delete | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetArticleById**
> Article GetArticleById(ctx, articleId)
Find article by ID

Returns a single article

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **articleId** | **int64**| ID of article to return | 

### Return type

[**Article**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateArticle**
> UpdateArticle(ctx, body)
Update an existing article



### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Article**](Article.md)| Article object that needs to be added to the db | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateArticleWithForm**
> UpdateArticleWithForm(ctx, articleId, optional)
Updates a article in the db with form data



### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **articleId** | **int64**| ID of article that needs to be updated | 
 **optional** | ***ArticleApiUpdateArticleWithFormOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a ArticleApiUpdateArticleWithFormOpts struct

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **status** | **optional.String**| Updated status of the article | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

