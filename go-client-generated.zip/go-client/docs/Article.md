# Article

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** |  | [optional] [default to null]
**Status** | **bool** | article status in the db | [optional] [default to null]
**Attributes** | **interface{}** | article attributes | [optional] [default to null]
**CreatedAt** | **int64** | article creation date | [optional] [default to null]
**UpdatedAt** | **int64** | article update date | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


