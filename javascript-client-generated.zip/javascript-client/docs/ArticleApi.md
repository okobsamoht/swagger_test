# SwaggerArticleDb.ArticleApi

All URIs are relative to *https://articledb.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addArticle**](ArticleApi.md#addArticle) | **POST** /article | Add a new article to the db
[**deleteArticle**](ArticleApi.md#deleteArticle) | **DELETE** /article/{articleId} | Deletes a article
[**getArticleById**](ArticleApi.md#getArticleById) | **GET** /article/{articleId} | Find article by ID
[**updateArticle**](ArticleApi.md#updateArticle) | **PUT** /article | Update an existing article
[**updateArticleWithForm**](ArticleApi.md#updateArticleWithForm) | **POST** /article/{articleId} | Updates a article in the db with form data


<a name="addArticle"></a>
# **addArticle**
> addArticle(body)

Add a new article to the db



### Example
```javascript
var SwaggerArticleDb = require('swagger_article_db');

var apiInstance = new SwaggerArticleDb.ArticleApi();

var body = new SwaggerArticleDb.Article(); // Article | Article object that needs to be added to the db


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.addArticle(body, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Article**](Article.md)| Article object that needs to be added to the db | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteArticle"></a>
# **deleteArticle**
> deleteArticle(articleId)

Deletes a article



### Example
```javascript
var SwaggerArticleDb = require('swagger_article_db');

var apiInstance = new SwaggerArticleDb.ArticleApi();

var articleId = 789; // Number | Article id to delete


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.deleteArticle(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article id to delete | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getArticleById"></a>
# **getArticleById**
> Article getArticleById(articleId)

Find article by ID

Returns a single article

### Example
```javascript
var SwaggerArticleDb = require('swagger_article_db');

var apiInstance = new SwaggerArticleDb.ArticleApi();

var articleId = 789; // Number | ID of article to return


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.getArticleById(articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| ID of article to return | 

### Return type

[**Article**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateArticle"></a>
# **updateArticle**
> updateArticle(body)

Update an existing article



### Example
```javascript
var SwaggerArticleDb = require('swagger_article_db');

var apiInstance = new SwaggerArticleDb.ArticleApi();

var body = new SwaggerArticleDb.Article(); // Article | Article object that needs to be added to the db


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.updateArticle(body, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Article**](Article.md)| Article object that needs to be added to the db | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="updateArticleWithForm"></a>
# **updateArticleWithForm**
> updateArticleWithForm(articleId, opts)

Updates a article in the db with form data



### Example
```javascript
var SwaggerArticleDb = require('swagger_article_db');

var apiInstance = new SwaggerArticleDb.ArticleApi();

var articleId = 789; // Number | ID of article that needs to be updated

var opts = { 
  'status': "status_example" // String | Updated status of the article
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.updateArticleWithForm(articleId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| ID of article that needs to be updated | 
 **status** | **String**| Updated status of the article | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

