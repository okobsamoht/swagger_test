# SwaggerArticleDb.Article

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**status** | **Boolean** | article status in the db | [optional] 
**attributes** | **Object** | article attributes | [optional] 
**createdAt** | **Number** | article creation date | [optional] 
**updatedAt** | **Number** | article update date | [optional] 


