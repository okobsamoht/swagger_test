# swagger_client.ArticleApi

All URIs are relative to *https://articledb.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_article**](ArticleApi.md#add_article) | **POST** /article | Add a new article to the db
[**delete_article**](ArticleApi.md#delete_article) | **DELETE** /article/{articleId} | Deletes a article
[**get_article_by_id**](ArticleApi.md#get_article_by_id) | **GET** /article/{articleId} | Find article by ID
[**update_article**](ArticleApi.md#update_article) | **PUT** /article | Update an existing article
[**update_article_with_form**](ArticleApi.md#update_article_with_form) | **POST** /article/{articleId} | Updates a article in the db with form data


# **add_article**
> add_article(body)

Add a new article to the db



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ArticleApi()
body = swagger_client.Article() # Article | Article object that needs to be added to the db

try:
    # Add a new article to the db
    api_instance.add_article(body)
except ApiException as e:
    print("Exception when calling ArticleApi->add_article: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Article**](Article.md)| Article object that needs to be added to the db | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_article**
> delete_article(article_id)

Deletes a article



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ArticleApi()
article_id = 789 # int | Article id to delete

try:
    # Deletes a article
    api_instance.delete_article(article_id)
except ApiException as e:
    print("Exception when calling ArticleApi->delete_article: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article id to delete | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_article_by_id**
> Article get_article_by_id(article_id)

Find article by ID

Returns a single article

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ArticleApi()
article_id = 789 # int | ID of article to return

try:
    # Find article by ID
    api_response = api_instance.get_article_by_id(article_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ArticleApi->get_article_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| ID of article to return | 

### Return type

[**Article**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_article**
> update_article(body)

Update an existing article



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ArticleApi()
body = swagger_client.Article() # Article | Article object that needs to be added to the db

try:
    # Update an existing article
    api_instance.update_article(body)
except ApiException as e:
    print("Exception when calling ArticleApi->update_article: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Article**](Article.md)| Article object that needs to be added to the db | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_article_with_form**
> update_article_with_form(article_id, status=status)

Updates a article in the db with form data



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ArticleApi()
article_id = 789 # int | ID of article that needs to be updated
status = 'status_example' # str | Updated status of the article (optional)

try:
    # Updates a article in the db with form data
    api_instance.update_article_with_form(article_id, status=status)
except ApiException as e:
    print("Exception when calling ArticleApi->update_article_with_form: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| ID of article that needs to be updated | 
 **status** | **str**| Updated status of the article | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

