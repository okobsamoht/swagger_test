# Swagger\Server\Api\ArticleApiInterface

All URIs are relative to *https://articledb.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addArticle**](ArticleApiInterface.md#addArticle) | **POST** /article | Add a new article to the db
[**deleteArticle**](ArticleApiInterface.md#deleteArticle) | **DELETE** /article/{articleId} | Deletes a article
[**getArticleById**](ArticleApiInterface.md#getArticleById) | **GET** /article/{articleId} | Find article by ID
[**updateArticle**](ArticleApiInterface.md#updateArticle) | **PUT** /article | Update an existing article
[**updateArticleWithForm**](ArticleApiInterface.md#updateArticleWithForm) | **POST** /article/{articleId} | Updates a article in the db with form data


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.article:
        class: Acme\MyBundle\Api\ArticleApi
        tags:
            - { name: "swagger_server.api", api: "article" }
    # ...
```

## **addArticle**
> addArticle($body)

Add a new article to the db



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ArticleApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\ArticleApiInterface;

class ArticleApi implements ArticleApiInterface
{

    // ...

    /**
     * Implementation of ArticleApiInterface#addArticle
     */
    public function addArticle(Article $body)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Swagger\Server\Model\Article**](../Model/Article.md)| Article object that needs to be added to the db |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **deleteArticle**
> deleteArticle($articleId)

Deletes a article



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ArticleApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\ArticleApiInterface;

class ArticleApi implements ArticleApiInterface
{

    // ...

    /**
     * Implementation of ArticleApiInterface#deleteArticle
     */
    public function deleteArticle($articleId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **int**| Article id to delete |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **getArticleById**
> Swagger\Server\Model\Article getArticleById($articleId)

Find article by ID

Returns a single article

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ArticleApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\ArticleApiInterface;

class ArticleApi implements ArticleApiInterface
{

    // ...

    /**
     * Implementation of ArticleApiInterface#getArticleById
     */
    public function getArticleById($articleId)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **int**| ID of article to return |

### Return type

[**Swagger\Server\Model\Article**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **updateArticle**
> updateArticle($body)

Update an existing article



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ArticleApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\ArticleApiInterface;

class ArticleApi implements ArticleApiInterface
{

    // ...

    /**
     * Implementation of ArticleApiInterface#updateArticle
     */
    public function updateArticle(Article $body)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Swagger\Server\Model\Article**](../Model/Article.md)| Article object that needs to be added to the db |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **updateArticleWithForm**
> updateArticleWithForm($articleId, $status)

Updates a article in the db with form data



### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/ArticleApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\ArticleApiInterface;

class ArticleApi implements ArticleApiInterface
{

    // ...

    /**
     * Implementation of ArticleApiInterface#updateArticleWithForm
     */
    public function updateArticleWithForm($articleId, $status = null)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **int**| ID of article that needs to be updated |
 **status** | **string**| Updated status of the article | [optional]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

