import connexion
import six

from swagger_server.models.article import Article  # noqa: E501
from swagger_server import util


def add_article(body):  # noqa: E501
    """Add a new article to the db

     # noqa: E501

    :param body: Article object that needs to be added to the db
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Article.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_article(articleId):  # noqa: E501
    """Deletes a article

     # noqa: E501

    :param articleId: Article id to delete
    :type articleId: int

    :rtype: None
    """
    return 'do some magic!'


def get_article_by_id(articleId):  # noqa: E501
    """Find article by ID

    Returns a single article # noqa: E501

    :param articleId: ID of article to return
    :type articleId: int

    :rtype: Article
    """
    return 'do some magic!'


def update_article(body):  # noqa: E501
    """Update an existing article

     # noqa: E501

    :param body: Article object that needs to be added to the db
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Article.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_article_with_form(articleId, status=None):  # noqa: E501
    """Updates a article in the db with form data

     # noqa: E501

    :param articleId: ID of article that needs to be updated
    :type articleId: int
    :param status: Updated status of the article
    :type status: str

    :rtype: None
    """
    return 'do some magic!'
