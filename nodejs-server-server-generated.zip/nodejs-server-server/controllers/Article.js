'use strict';

var utils = require('../utils/writer.js');
var Article = require('../service/ArticleService');

module.exports.addArticle = function addArticle (req, res, next) {
  var body = req.swagger.params['body'].value;
  Article.addArticle(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteArticle = function deleteArticle (req, res, next) {
  var articleId = req.swagger.params['articleId'].value;
  Article.deleteArticle(articleId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getArticleById = function getArticleById (req, res, next) {
  var articleId = req.swagger.params['articleId'].value;
  Article.getArticleById(articleId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateArticle = function updateArticle (req, res, next) {
  var body = req.swagger.params['body'].value;
  Article.updateArticle(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateArticleWithForm = function updateArticleWithForm (req, res, next) {
  var articleId = req.swagger.params['articleId'].value;
  var status = req.swagger.params['status'].value;
  Article.updateArticleWithForm(articleId,status)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
