'use strict';


/**
 * Add a new article to the db
 * 
 *
 * body Article Article object that needs to be added to the db
 * no response value expected for this operation
 **/
exports.addArticle = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Deletes a article
 * 
 *
 * articleId Long Article id to delete
 * no response value expected for this operation
 **/
exports.deleteArticle = function(articleId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Find article by ID
 * Returns a single article
 *
 * articleId Long ID of article to return
 * returns Article
 **/
exports.getArticleById = function(articleId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update an existing article
 * 
 *
 * body Article Article object that needs to be added to the db
 * no response value expected for this operation
 **/
exports.updateArticle = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Updates a article in the db with form data
 * 
 *
 * articleId Long ID of article that needs to be updated
 * status String Updated status of the article (optional)
 * no response value expected for this operation
 **/
exports.updateArticleWithForm = function(articleId,status) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

