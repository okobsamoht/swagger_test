# Swagger\Client\ArticleApi

All URIs are relative to *https://articledb.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addArticle**](ArticleApi.md#addArticle) | **POST** /article | Add a new article to the db
[**deleteArticle**](ArticleApi.md#deleteArticle) | **DELETE** /article/{articleId} | Deletes a article
[**getArticleById**](ArticleApi.md#getArticleById) | **GET** /article/{articleId} | Find article by ID
[**updateArticle**](ArticleApi.md#updateArticle) | **PUT** /article | Update an existing article
[**updateArticleWithForm**](ArticleApi.md#updateArticleWithForm) | **POST** /article/{articleId} | Updates a article in the db with form data


# **addArticle**
> addArticle($body)

Add a new article to the db



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ArticleApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\Article(); // \Swagger\Client\Model\Article | Article object that needs to be added to the db

try {
    $apiInstance->addArticle($body);
} catch (Exception $e) {
    echo 'Exception when calling ArticleApi->addArticle: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\Article**](../Model/Article.md)| Article object that needs to be added to the db |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deleteArticle**
> deleteArticle($article_id)

Deletes a article



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ArticleApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 789; // int | Article id to delete

try {
    $apiInstance->deleteArticle($article_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticleApi->deleteArticle: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article id to delete |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getArticleById**
> \Swagger\Client\Model\Article getArticleById($article_id)

Find article by ID

Returns a single article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ArticleApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 789; // int | ID of article to return

try {
    $result = $apiInstance->getArticleById($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticleApi->getArticleById: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| ID of article to return |

### Return type

[**\Swagger\Client\Model\Article**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **updateArticle**
> updateArticle($body)

Update an existing article



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ArticleApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\Article(); // \Swagger\Client\Model\Article | Article object that needs to be added to the db

try {
    $apiInstance->updateArticle($body);
} catch (Exception $e) {
    echo 'Exception when calling ArticleApi->updateArticle: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\Article**](../Model/Article.md)| Article object that needs to be added to the db |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **updateArticleWithForm**
> updateArticleWithForm($article_id, $status)

Updates a article in the db with form data



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ArticleApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$article_id = 789; // int | ID of article that needs to be updated
$status = "status_example"; // string | Updated status of the article

try {
    $apiInstance->updateArticleWithForm($article_id, $status);
} catch (Exception $e) {
    echo 'Exception when calling ArticleApi->updateArticleWithForm: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| ID of article that needs to be updated |
 **status** | **string**| Updated status of the article | [optional]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

