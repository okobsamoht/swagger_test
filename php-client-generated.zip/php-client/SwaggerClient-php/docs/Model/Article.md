# Article

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**status** | **bool** | article status in the db | [optional] 
**attributes** | **object** | article attributes | [optional] 
**created_at** | **int** | article creation date | [optional] 
**updated_at** | **int** | article update date | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


